#!/bin/sh

iface=$1
mac=$2
act=$3

supp_mgmt=$(uci -q get functionlist.functionlist.SUPPORT_MANAGEMENT_SSID)

[ "$supp_mgmt" != "1" ] && exit 0

wifi0_opmode=$(uci -q get wireless.wifi0.opmode)

[ "$wifi0_opmode" != "wds_sta" ] && exit 0

sta_ifname=$(uci -q get wireless.wifi0_wds_sta.ifname)

if [ "$iface" = "$sta_ifname" -a "$act" = "join" ]; then
    cfg80211tool $sta_ifname extap 0
fi

