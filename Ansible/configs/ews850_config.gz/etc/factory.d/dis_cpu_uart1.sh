#! /bin/sh
# upgrade host test firmware to BT CC2640R2F

########################################################
# Definition
########################################################
BOARD_CFG="/etc/factory.d/board.cfg"

if [ -e $BOARD_CFG ]; then
    . $BOARD_CFG
else
    echo "$BOARD_CFG is not exist!";
    exit 1;
fi

BT_CC2640R2F_CFG="/etc/factory.d/bt_cc2640r2f.cfg"

if [ -e $BT_CC2640R2F_CFG ]; then
    . $BT_CC2640R2F_CFG
else
    echo "$BT_CC2640R2F_CFG is not exist!";
    exit 1;
fi

########################################################
# Debug message
########################################################
DEBUG=0;

DBG() {
	[ $DEBUG -gt 0 ] && echo "=> $@" > /dev/console
}
dbg() {
	[ $DEBUG -gt 1 ] &&echo "$@" > /dev/console
}

########################################################
# sub-Functions
########################################################
#-----------------------------------------------------
# dis_uart1_ipq401x()  
#-----------------------------------------------------
dis_uart1_ipq401x() {
    DBG "dis_uart1_ipq401x()"

	uart1tx_tlmm_gpio_cfg_reg=`printf "0x10%02x000" $UART1_TX_GPIO`;
	uart1rx_tlmm_gpio_cfg_reg=`printf "0x10%02x000" $UART1_RX_GPIO`;
	dbg "uart1tx_tlmm_gpio_cfg_reg=$uart1tx_tlmm_gpio_cfg_reg";
	dbg "uart1rx_tlmm_gpio_cfg_reg=$uart1rx_tlmm_gpio_cfg_reg";

	#0x4801 means TLMM GPIO Configuration reset states
	devmem $uart1tx_tlmm_gpio_cfg_reg w 0x4801
	devmem $uart1rx_tlmm_gpio_cfg_reg w 0x4801

	# read back to check
	rd_val_t=`devmem $uart1tx_tlmm_gpio_cfg_reg`;
	rd_val_r=`devmem $uart1rx_tlmm_gpio_cfg_reg`;

	if [ `printf "%d" $rd_val_t` -eq `printf "%d" 0x4801` ]; then
		dbg "disabel uart1 TX OK";
	else
		echo "disable TX Fail";
		exit 1;
	fi

	if [ `printf "%d" $rd_val_r` -eq `printf "%d" 0x4801` ]; then
		dbg "disabel uart1 RX OK";
	else
		echo "disable RX Fail";
		exit 1;
	fi

	echo "OK";
}

#-----------------------------------------------------
# dis_uart1_ipq807x()  
#-----------------------------------------------------
dis_uart1_ipq807x() {
    DBG "dis_uart1_ipq807x()"

	uart1tx_tlmm_gpio_cfg_reg=`printf "0x10%02x000" $UART1_TX_GPIO`;
	uart1rx_tlmm_gpio_cfg_reg=`printf "0x10%02x000" $UART1_RX_GPIO`;
	dbg "uart1tx_tlmm_gpio_cfg_reg=$uart1tx_tlmm_gpio_cfg_reg";
	dbg "uart1rx_tlmm_gpio_cfg_reg=$uart1rx_tlmm_gpio_cfg_reg";

	#0x0001 means TLMM GPIO Configuration reset states
	devmem $uart1tx_tlmm_gpio_cfg_reg w 0x0001
	devmem $uart1rx_tlmm_gpio_cfg_reg w 0x0001

	# read back to check
	rd_val_t=`devmem $uart1tx_tlmm_gpio_cfg_reg`;
	rd_val_r=`devmem $uart1rx_tlmm_gpio_cfg_reg`;

	if [ `printf "%d" $rd_val_t` -eq `printf "%d" 0x0001` ]; then
		dbg "disabel uart1 TX OK";
	else
		echo "disable TX Fail";
		exit 1;
	fi

	if [ `printf "%d" $rd_val_r` -eq `printf "%d" 0x0001` ]; then
		dbg "disabel uart1 RX OK";
	else
		echo "disable RX Fail";
		exit 1;
	fi

	echo "OK";
}


########################################################
# START
########################################################
case $CPU in
    "IPQ4019"|"IPQ4018")
        dis_uart1_ipq401x;
        ;;
    "IPQ8070"|"IPQ8072"|"IPQ8074")
        dis_uart1_ipq807x;
        ;;
    *)
        echo "unknown CPU type!";
        exit 1;
        ;;
esac
