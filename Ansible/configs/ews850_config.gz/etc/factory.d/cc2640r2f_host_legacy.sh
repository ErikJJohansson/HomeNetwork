#! /bin/sh
# upgrade host test firmware to BT CC2640R2F

########################################################
# Definition
########################################################
BT_CC2640R2F_CFG="/etc/factory.d/bt_cc2640r2f.cfg"

if [ -e $BT_CC2640R2F_CFG ]; then
    . $BT_CC2640R2F_CFG
else
    echo "$BT_CC2640R2F_CFG is not exist!";
    exit 1;
fi

retry=5
########################################################
# Debug message
########################################################
DEBUG=0;

DBG() {
    [ $DEBUG -gt 0 ] && echo "=> $@" > /dev/console
}
dbg() {
    [ $DEBUG -gt 1 ] &&	echo "$@" > /dev/console
}

########################################################
# sub-Functions
########################################################

#-----------------------------------------------------
# export_gpio()
# $1=direction[in/out]
# $2=gpio pin number
# $3=active_low[0/1]
#-----------------------------------------------------
export_gpio() {
    dbg "export_gpio $@";

    GPIO_EXPORT="/sys/class/gpio/export"
    inout=$1;
    gpio=$2;
    active_low=$3;

    [ -e $GPIO_EXPORT ] && {
            # export
            if [ -e /sys/class/gpio/gpio$gpio ]; then
                dbg "/sys/class/gpio/gpio$gpio is already exist";
            else
                [ -n $gpio ] && echo $gpio > $GPIO_EXPORT;
            fi

            # direction/active_low
            if [ -e /sys/class/gpio/gpio$gpio ]; then
                echo $inout > /sys/class/gpio/gpio$gpio/direction;
                [ -n $active_low ] && echo $active_low > /sys/class/gpio/gpio$gpio/active_low;
            else
                dbg "export $gpio fail";
                exit 1;
            fi
        }
}


#-----------------------------------------------------
# export_bt_gpio()
#-----------------------------------------------------
export_bt_gpio() {
    dbg export_bt_gpio;

    # BT_BOOT_LOADER
    export_gpio "out" $BT_BOOT_LOADER $BT_BOOT_LOADER_ACTIVE_LOW;

    # BT_RST_BLE
    export_gpio "out" $BT_RST_BLE $BT_RST_BLE_ACTIVE_LOW;
}

#-----------------------------------------------------
# switch_to_loader_mode()
#-----------------------------------------------------
switch_to_loader_mode() {
    dbg "switch_to_loader_mode"

    # loader mode
    echo 0 > /sys/class/gpio/gpio$BT_BOOT_LOADER/value;

    # reset
    echo 0 > /sys/class/gpio/gpio$BT_RST_BLE/value;
    sleep 1;
    echo 1 > /sys/class/gpio/gpio$BT_RST_BLE/value;
}

#-----------------------------------------------------
# switch_to_kernel_mode()
#-----------------------------------------------------
switch_to_kernel_mode() {
    dbg "switch_to_kernel_mode"

    # kernel mode
    echo 1 > /sys/class/gpio/gpio$BT_BOOT_LOADER/value;

    # reset
    echo 0 > /sys/class/gpio/gpio$BT_RST_BLE/value;
    sleep 1;
    echo 1 > /sys/class/gpio/gpio$BT_RST_BLE/value;
}

#-----------------------------------------------------
# upgrade_host_test_fw()
#-----------------------------------------------------
upgrade_host_test_fw() {
    dbg "upgrade_host_test_fw"

    for sitenu in $(seq 1 $retry)
        do
            cc2538-bsl.py -p /dev/ttyMSM1 -b 500000 -e -w -v /lib/firmware/cc2640r2f/host_test_cc2640r2lp_app_legacy.hex  2>&1 | tee upgrade_BLE_OS.log
            result=`cat upgrade_BLE_OS.log  | grep ERROR | awk -F ":" '{print $1}'`
    		rm upgrade_BLE_OS.log
            if [ "$result" == "ERROR" ];then
                    echo "do upgrade os again"
                    retry=`expr $retry - 1`
            else
                    echo "upgrade successful"
    				break
            fi
    done
}


########################################################
# START
########################################################
export_bt_gpio;
switch_to_loader_mode;
upgrade_result=`upgrade_host_test_fw`;
pass_index=`echo $upgrade_result | grep "upgrade successful"`;
dbg "pass_index=$pass_index"

if [ -n "$pass_index" ]; then
    echo "upgrade host test firmware OK";
else
    echo "upgrade fail";
    exit 1;
fi

switch_to_kernel_mode
