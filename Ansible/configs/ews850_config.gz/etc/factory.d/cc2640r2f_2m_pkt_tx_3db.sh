#! /bin/sh
# upgrade host test firmware to BT CC2640R2F

########################################################
# Definition
########################################################
BT_CC2640R2F_CFG="/etc/factory.d/bt_cc2640r2f.cfg"

if [ -e $BT_CC2640R2F_CFG ]; then
    . $BT_CC2640R2F_CFG
else
    echo "$BT_CC2640R2F_CFG is not exist!";
    exit 1;
fi

retry=5

PKT_2M_3DB_TX_CHXX_2402_FW="host_test_cc2640r2lp_app_3db_chxx_2402.hex"
PKT_2M_3DB_TX_CH17_2440_FW="host_test_cc2640r2lp_app_3db_ch17_2440.hex"
PKT_2M_3DB_TX_CH18_2442_FW="host_test_cc2640r2lp_app_3db_ch18_2442.hex"
PKT_2M_3DB_TX_CH39_2480_FW="host_test_cc2640r2lp_app_3db_ch39_2480.hex"

########################################################
# Debug message
########################################################
DEBUG=2;

DBG() {
    [ $DEBUG -gt 0 ] && echo "=> $@" > /dev/console
}
dbg() {
    [ $DEBUG -gt 1 ] &&	echo "$@" > /dev/console
}

########################################################
# sub-Functions
########################################################

#-----------------------------------------------------
# usage
#-----------------------------------------------------
usage() {
    dbg "usage $@";

    echo "cc2640r2f_2m_pkt_tx_3db.sh [2402/2440/2442/2480]"
}


#-----------------------------------------------------
# export_gpio()
# $1=direction[in/out]
# $2=gpio pin number
# $3=active_low[0/1]
#-----------------------------------------------------
export_gpio() {
    dbg "export_gpio $@";

    GPIO_EXPORT="/sys/class/gpio/export"
    inout=$1;
    gpio=$2;
    active_low=$3;

    [ -e $GPIO_EXPORT ] && {
            # export
            if [ -e /sys/class/gpio/gpio$gpio ]; then
                dbg "/sys/class/gpio/gpio$gpio is already exist";
            else
                [ -n $gpio ] && echo $gpio > $GPIO_EXPORT;
            fi

            # direction/active_low
            if [ -e /sys/class/gpio/gpio$gpio ]; then
                echo $inout > /sys/class/gpio/gpio$gpio/direction;
                [ -n $active_low ] && echo $active_low > /sys/class/gpio/gpio$gpio/active_low;
            else
                dbg "export $gpio fail";
                exit 1;
            fi
        }
}


#-----------------------------------------------------
# export_bt_gpio()
#-----------------------------------------------------
export_bt_gpio() {
    dbg export_bt_gpio;

    # BT_BOOT_LOADER
    export_gpio "out" $BT_BOOT_LOADER $BT_BOOT_LOADER_ACTIVE_LOW;

    # BT_RST_BLE
    export_gpio "out" $BT_RST_BLE $BT_RST_BLE_ACTIVE_LOW;
}

#-----------------------------------------------------
# switch_to_loader_mode()
#-----------------------------------------------------
switch_to_loader_mode() {
    dbg "switch_to_loader_mode"

    # loader mode
    echo 0 > /sys/class/gpio/gpio$BT_BOOT_LOADER/value;

    # reset
    echo 0 > /sys/class/gpio/gpio$BT_RST_BLE/value;
    sleep 1;
    echo 1 > /sys/class/gpio/gpio$BT_RST_BLE/value;
}

#-----------------------------------------------------
# switch_to_kernel_mode()
#-----------------------------------------------------
switch_to_kernel_mode() {
    dbg "switch_to_kernel_mode"

    # kernel mode
    echo 1 > /sys/class/gpio/gpio$BT_BOOT_LOADER/value;

    # reset
    echo 0 > /sys/class/gpio/gpio$BT_RST_BLE/value;
    sleep 1;
    echo 1 > /sys/class/gpio/gpio$BT_RST_BLE/value;
}

#-----------------------------------------------------
# upgrade_PKT_2M_TX_3DBfirmware()
#-----------------------------------------------------
upgrade_PKT_2M_TX_3DBfirmware() {
    dbg "upgrade_PKT_2M_TX_3DBfirmware $@"

case "$1" in
    "2402")
        PKT_2M_TX_FW=$PKT_2M_3DB_TX_CHXX_2402_FW;
        ;;
    "2440")
        PKT_2M_TX_FW=$PKT_2M_3DB_TX_CH17_2440_FW;
        ;;
    "2442")
        PKT_2M_TX_FW=$PKT_2M_3DB_TX_CH18_2442_FW;
        ;;
    "2480")
        PKT_2M_TX_FW=$PKT_2M_3DB_TX_CH39_2480_FW;
        ;;
    *)
        echo "not support $1";
        exit 1;
        ;;
esac
    dbg "PKT_2M_TX_FW=$PKT_2M_TX_FW";

    for sitenu in $(seq 1 $retry)
        do
            cc2538-bsl.py -p /dev/ttyMSM1 -b 500000 -e -w -v /lib/firmware/cc2640r2f/$PKT_2M_TX_FW  2>&1 | tee upgrade_BLE_OS.log
            result=`cat upgrade_BLE_OS.log  | grep ERROR | awk -F ":" '{print $1}'`
    		rm upgrade_BLE_OS.log
            if [ "$result" == "ERROR" ];then
                    echo "do upgrade os again"
                    retry=`expr $retry - 1`
            else
                    echo "upgrade successful"
    				break
            fi
    done
}


########################################################
# START
########################################################
case "$1" in
    "2402"|"2440"|"2442"|"2480")
        export_bt_gpio;
        switch_to_loader_mode;
        upgrade_result=`upgrade_PKT_2M_TX_3DBfirmware $1`;
        pass_index=`echo $upgrade_result | grep "upgrade successful"`;
        dbg "pass_index=$pass_index";
        switch_to_kernel_mode;
        if [ -n "$pass_index" ]; then
            echo "upgrade $1 test firmware OK";
        else
            echo "upgrade fail";
            exit 1;
        fi
        ;;
    *)
        usage;
    ;;
esac
