#!/bin/sh

# please check the senao factory hotplug rule => /etc/hotplug-sn-factory.json 
#                                             => /etc/factory.d/rc.button/*

BUTTON_ACTION=""

[ -f /tmp/button_log ] && BUTTON_ACTION=`cat /tmp/button_log`

if [ "${BUTTON_ACTION}" == "pressed" ]; then

	echo "====error: detect button is pressed, please release the button & try again!"
	return 0

elif [ "${BUTTON_ACTION}" == "released" -o "${BUTTON_ACTION}" == "" ]; then
    
	echo ""
	echo "===BUTTON is released now, start the POE reset button test!==="
	echo "" > /tmp/button_press_duration_log

	tail -f /tmp/button_press_duration_log
fi
