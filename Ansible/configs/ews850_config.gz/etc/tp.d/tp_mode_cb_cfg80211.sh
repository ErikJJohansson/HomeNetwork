ifconfig eth0 0.0.0.0
ifconfig eth0 down
ifconfig eth0 hw ether 88:DC:96:1A:2B:3C
brctl delif br-lan eth0
ifconfig br-lan down
brctl delbr br-lan
brctl addbr br-lan
ifconfig br-lan 192.168.1.2 up
brctl addif br-lan eth0
ifconfig eth0 up
ifconfig wifi0 down

wpa_supplicant -g /var/run/wpa_supplicantglobal -B -P /var/run/wpa_supplicant-global.pid
cp /etc/tp.d/wpa_supplicant-ath0.conf /var/run/
cp /etc/tp.d/wpa_supplicant-ath2.conf /var/run/
cp /etc/tp.d/wpa_supplicant-ath4.conf /var/run/

#wifi0
iwpriv wifi0 setHwaddr 00:11:22:99:CC:22
ifconfig wifi0 up

wlanconfig ath0 create wlandev wifi0 wlanmode sta -cfg80211
iw phy "$(cat /sys/class/net/wifi0/phy80211/name)" interface add ath0 type managed
iw ath0 set 4addr on >/dev/null 2>&1
iwconfig ath0 channel 6
cfg80211tool ath0 wds 1

wpa_cli -g /var/run/wpa_supplicantglobal interface_add ath0 /var/run/wpa_supplicant-ath0.conf nl80211 /var/run/wpa_supplicant-ath0  br-lan

iwpriv ath0 mode 11GHE40
iwpriv ath0 shortgi 1
iwpriv ath0 disablecoext 1
iwconfig ath0 essid 24g

ifconfig ath0 up
brctl addif br-lan ath0

#wifi1
ifconfig wifi1 down
iwpriv wifi1 setHwaddr 00:11:22:CC:AA:44
ifconfig wifi1 up

wlanconfig ath2 create wlandev wifi1 wlanmode sta -cfg80211
iw phy "$(cat /sys/class/net/wifi1/phy80211/name)" interface add ath2 type managed
iw ath2 set 4addr on >/dev/null 2>&1
iwconfig ath2 channel 149

cfg80211tool ath2 wds 1

wpa_cli -g /var/run/wpa_supplicantglobal interface_add ath2 /var/run/wpa_supplicant-ath2.conf nl80211 /var/run/wpa_supplicant-ath2  br-lan

iwpriv ath2 mode 11AHE80
iwpriv ath2 shortgi 1
iwpriv ath2 disablecoext 1
iwconfig ath2 essid 11ax

ifconfig ath2 up
brctl addif br-lan ath2

#wifi2
ifconfig wifi2 down
iwpriv wifi2 setHwaddr 00:11:22:FF:88:99
ifconfig wifi2 up

wlanconfig ath4 create wlandev wifi2 wlanmode sta -cfg80211
iw phy "$(cat /sys/class/net/wifi2/phy80211/name)" interface add ath4 type managed
iw ath4 set 4addr on >/dev/null 2>&1
iwconfig ath4 channel 149

cfg80211tool ath4 wds 1

wpa_cli -g /var/run/wpa_supplicantglobal interface_add ath4 /var/run/wpa_supplicant-ath4.conf nl80211 /var/run/wpa_supplicant-ath4  br-lan

iwpriv ath4 mode 11ACVHT80
iwpriv ath4 shortgi 1
iwpriv ath4 disablecoext 1
iwconfig ath4 essid scan

ifconfig ath4 up
brctl addif br-lan ath4
