ifconfig eth0 0.0.0.0
ifconfig eth0 down
brctl delif br-lan eth0
ifconfig br-lan down
brctl delbr br-lan
brctl addbr br-lan
ifconfig br-lan 192.168.1.1 up
brctl addif br-lan eth0
ifconfig eth0 up
ifconfig wifi0 down

hostapd -g /var/run/hostapd/global -B -P /var/run/hostapd-global.pid
cp /etc/tp.d/hostapd-ath0.conf /var/run/
cp /etc/tp.d/hostapd-ath2.conf /var/run/
cp /etc/tp.d/hostapd-ath4.conf /var/run/

iwpriv wifi0 setHwaddr 00:11:22:88:E4:B0

ifconfig wifi0 up

wlanconfig ath0 create wlandev wifi0 wlanmode ap -cfg80211
iw phy "$(cat /sys/class/net/wifi0/phy80211/name)" interface add ath0 type __ap
iw ath0 set 4addr on >/dev/null 2>&1
iwconfig ath0 channel 6

wpa_cli -g /var/run/hostapd/global raw ADD bss_config=ath0:/var/run/hostapd-ath0.conf

iwpriv ath0 mode 11GHE40
iwpriv ath0 shortgi 1
iwpriv ath0 disablecoext 1
iwconfig ath0 essid 24g

#iwconfig ath0 essid "24g" channel 6 rate auto
#iwconfig ath0 key off

#wpa_cli -g /var/run/hostapd/global raw ADD bss_config=ath0:/var/run/hostapd-ath0.conf

ifconfig ath0 up
brctl addif br-lan ath0


ifconfig wifi1 down
iwpriv wifi1 setHwaddr 00:11:22:88:E4:B1

ifconfig wifi1 up

wlanconfig ath2 create wlandev wifi1 wlanmode ap -cfg80211
iw phy "$(cat /sys/class/net/wifi1/phy80211/name)" interface add ath2 type __ap
iw ath2 set 4addr on >/dev/null 2>&1
iwconfig ath2 channel 149

wpa_cli -g /var/run/hostapd/global raw ADD bss_config=ath2:/var/run/hostapd-ath2.conf

iwpriv ath2 mode 11AHE80
iwpriv ath2 shortgi 1
iwpriv ath2 disablecoext 1
iwconfig ath2 essid 11ax
#iwconfig ath2 essid "11ax" channel 149 rate auto 
#iwconfig ath2 key off

#wpa_cli -g /var/run/hostapd/global raw ADD bss_config=ath2:/var/run/hostapd-ath2.conf

ifconfig ath2 up
brctl addif br-lan ath2

ifconfig wifi2 down
iwpriv wifi2 setHwaddr 00:11:22:88:E4:B2

ifconfig wifi2 up

wlanconfig ath4 create wlandev wifi2 wlanmode ap -cfg80211
iw phy "$(cat /sys/class/net/wifi2/phy80211/name)" interface add ath4 type __ap
iw ath4 set 4addr on >/dev/null 2>&1
iwconfig ath4 channel 36

wpa_cli -g /var/run/hostapd/global raw ADD bss_config=ath4:/var/run/hostapd-ath4.conf

iwpriv ath4 mode 11ACVHT80
iwpriv ath4 shortgi 1
iwpriv ath4 disablecoext 1
iwconfig ath4 essid scan
iwpriv ath4 wds 1
#iwconfig ath4 essid "scan" channel 149 rate auto 
#iwconfig ath4 key off

#wpa_cli -g /var/run/hostapd/global raw ADD bss_config=ath4:/var/run/hostapd-ath4.conf

ifconfig ath4 up
brctl addif br-lan ath4
